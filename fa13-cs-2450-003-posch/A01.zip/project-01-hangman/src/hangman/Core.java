package hangman;

public class Core
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		HangmanGame game = new HangmanGame();
		game.start();
	}

}
