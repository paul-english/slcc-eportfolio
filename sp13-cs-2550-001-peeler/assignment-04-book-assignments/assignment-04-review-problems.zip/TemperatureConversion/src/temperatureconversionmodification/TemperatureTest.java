/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package temperatureconversionmodification;

import javax.swing.JFrame;

/**
 *
 * @author nrub
 */
public class TemperatureTest
{

	public static void main(String[] args)
	{
		AppFrame appFrame = new AppFrame();
		appFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		appFrame.setSize(260, 180);
		appFrame.setVisible(true);
	}
}
