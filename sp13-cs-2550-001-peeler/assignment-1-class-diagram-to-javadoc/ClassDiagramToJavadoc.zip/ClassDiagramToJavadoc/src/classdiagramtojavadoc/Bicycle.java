package classdiagramtojavadoc;

/**
 * A two wheeled pedal powered vehicle.
 * 
 * @author Paul English
 */
public class Bicycle extends Vehicle {
    
    /**
     * Public Bicycle constructor.
     */
    public Bicycle() {
        
    }
    
}
