package classdiagramtojavadoc;

/**
 * A default, and generated class to run for no reason on build.
 * 
 * @author Paul English
 */
public class ClassDiagramToJavadoc {

    /**
     * Left here, just because
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // there is no application logic.
    }
}
