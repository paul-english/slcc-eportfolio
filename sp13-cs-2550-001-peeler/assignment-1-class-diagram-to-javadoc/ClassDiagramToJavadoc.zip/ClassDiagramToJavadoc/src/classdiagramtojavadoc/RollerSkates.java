package classdiagramtojavadoc;

/**
 * A foot worn vehicle for moving smaller distances, in a terribly 90's fashion.
 * 
 * @author Paul English
 */
public class RollerSkates extends Vehicle {
    
    /**
     * A constructor for instantiating these wheeled shoes on your feet.
     */
    public RollerSkates() {
        
    }
}
